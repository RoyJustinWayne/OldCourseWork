#include <stdexcept>
#include <iostream>
#include "ExpressionTree.h"

	template <typename DataType>
	ExprTree<DataType>::ExprTree()
	{
		root = NULL; //Start of the tree  == null.
	}
	template <typename DataType>
	ExprTree<DataType>::ExprTree(const ExprTree& source)
	{
		*this = source;
	}

	template <typename DataType>
	ExprTree& ExprTree<DataType>::operator=(const ExprTree& source)
	{
		if (source != *this)
		{
			makeEmpty();
		}
		clone(root, source.root);
		return *this;
	}
	//Using similar method to PP slide
	template<typename DataType>
	void ExprTree<DataType>::clone(ExprTreeNode *source)
	{
		if (source == NULL)
		{
			return new ExprTreeNode(source->dataItem, clone(source->left),clone(source->right));
		}
	}

	// Destructor
	template <typename DataType>
	ExprTree<DataType>::~ExprTree()
	{
		makeEmpty();
	}
	
	//Using makeEmpty example from powerpoint.
	template <typename DataType>
	void makeEmpty(const ExprTree * & source)
	{
		if (source != NULL)
		{
			makeEmpty(source->left);
			makeEmpty(source->right);
			delete source;
		}
		source = NULL;
	}

	// Expression tree manipulation operations
	template <typename DataType>
	void ExprTree<DataType>::build()
	{
		String input = "";
		cout << "Enter in infix notation";
		cin << input;

		//Fix the implementation of taking the String input and making a tree

	}

	template <typename DataType>
	void ExprTree<DataType>::expression() const
	{

	}

	template <typename DataType>
	DataType ExprTree<DataType>::evaluate() const throw (logic_error)
	{
	
	}
	// Clear tree -- SEE PP, use either post-order or pre-order notation to loop through it all.
	template <typename DataType>
	void ExprTree<DataType>::clear()
	{
		//Isnt this the same as deconstructor? OR is this looking to keep the acual tree intact and remove data inside.
		makeEmpty();
	}

	template <typename DataType>
	void ExprTree<DataType>::commute()
	{

	}

	template <typename DataType>
	bool ExprTree<DataType>::isEquivalent(const ExprTree& source) const
	{

	}

	// Output the tree structure -- used in testing/debugging
	template <typename DataType>
	void ExprTree<DataType>::showStructure() const
	{

	}


	//May need to move/remove this. Check later.
	template<typename DataType>
	ExprTree<DataType>::ExprTreeNode::ExprTreeNode(char elem, ExprTreeNode * leftPtr, ExprTreeNode * rightPtr)
	{
		dataItem = NULL;
		*left = NULL;    
		*right = NULL;
	}